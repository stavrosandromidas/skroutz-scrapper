import requests
from bs4 import BeautifulSoup
import pandas as pd
import time

# ----------------------------------------
# Ρυθμίσεις
# ----------------------------------------
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128 Safari/537.36"
}

INPUT_FILE = "products.csv"   # το δικό σου αρχείο
OUTPUT_FILE = "results.xlsx"  # αρχείο αποτελεσμάτων

# Διαβάζουμε CSV με προϊόντα
df = pd.read_csv(INPUT_FILE, encoding="utf-8-sig")

results = []

for _, row in df.iterrows():
    query = str(row["Όνομα"]).strip()
    wholesale_price = float(row["Χονδρική"])
    code = row["Κωδικός"]

    print(f"🔍 Αναζήτηση για: {query}")

    # URL Skroutz
    url = f"https://www.skroutz.gr/search?keyphrase={query.replace(' ', '+')}"
    response = requests.get(url, headers=HEADERS)
    print(response.text[:500])



    if response.status_code != 200:
        print(f"⚠️ HTTP {response.status_code} για {query}")
        continue

    soup = BeautifulSoup(response.text, "html.parser")

    # Αναζήτηση πρώτης τιμής
    price_element = soup.find("span", class_="price")

    if not price_element:
        print(f"⚠️ Δεν βρέθηκε τιμή για {query}")
        retail_price = None
        profit_margin = None
    else:
        try:
            price_text = price_element.get_text().strip()
            price_text = price_text.replace("€", "").replace(".", "").replace(",", ".").strip()
            retail_price = float(price_text)
            profit_margin = (retail_price - wholesale_price) / wholesale_price * 100
            print(f"✅ Βρέθηκε: {retail_price}€ | Κέρδος: {profit_margin:.2f}%")
        except:
            print(f"⚠️ Σφάλμα ανάλυσης τιμής για {query}")
            retail_price = None
            profit_margin = None

    results.append({
        "Κωδικός": code,
        "Όνομα": query,
        "Χονδρική": wholesale_price,
        "Λιανική Skroutz": retail_price,
        "Κέρδος %": round(profit_margin, 2) if profit_margin else None
    })

    time.sleep(2)  # καθυστέρηση για να μην μπλοκάρει το Skroutz

# Αποθήκευση σε Excel
df_out = pd.DataFrame(results)
df_out.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

print(f"\n🎉 Ολοκληρώθηκε! Δες το αρχείο: {OUTPUT_FILE}")
